# GitHub 仓库设置与自动打包

## 📋 前提条件

1. 拥有 GitHub 账号
2. 已安装 Git

## 🚀 初始化 GitHub 仓库

### 步骤 1：创建 GitHub 仓库

1. 访问 https://github.com/new
2. 仓库名：`DocFormatter`
3. 公开或私有均可
4. **不要** 勾选 "Initialize this repository with a README"
5. 点击 "Create repository"

### 步骤 2：本地初始化 Git

```bash
cd /Users/mac/Documents/量化/office/docformatter

# 初始化 Git
git init

# 添加所有文件
git add .

# 创建初始提交
git commit -m "Initial commit: DocFormatter v1.0.0"

# 添加远程仓库（替换为你的仓库地址）
git remote add origin https://github.com/你的用户名/DocFormatter.git

# 推送代码
git branch -M main
git push -u origin main
```

### 步骤 3：创建 Release 标签

```bash
# 创建版本标签
git tag v1.0.0

# 推送标签（触发自动打包）
git push origin v1.0.0
```

## 🤖 自动打包流程

推送标签后，GitHub Actions 会自动：

1. **Windows 打包**
   - 使用 `windows-latest` 运行器
   - 生成 `DocFormatter.exe`
   - 上传为 Release 附件

2. **macOS 打包**
   - 使用 `macos-latest` 运行器
   - 生成 `DocFormatter.dmg`
   - 上传为 Release 附件

3. **创建 Release**
   - 在 GitHub Releases 页面创建新版本
   - 自动附加打包文件

## 📦 查看打包结果

1. 访问仓库页面
2. 点击 "Releases"
3. 下载对应系统的安装包

##  手动触发打包

如果不推送标签，也可以手动触发：

1. 访问仓库 Actions 页面
2. 选择 "Build DocFormatter" 工作流
3. 点击 "Run workflow"
4. 选择分支（通常是 main）
5. 点击 "Run workflow"

## 📝 修改打包配置

编辑 `.github/workflows/build.yml` 可以：

### 修改触发条件

```yaml
on:
  push:
    branches:
      - main  # 每次推送到 main 分支时打包
  workflow_dispatch:  # 允许手动触发
```

### 修改 Python 版本

```yaml
- name: 设置 Python
  uses: actions/setup-python@v5
  with:
    python-version: '3.12'  # 修改版本号
```

### 添加 Linux 打包

```yaml
build-linux:
  runs-on: ubuntu-latest
  steps:
    - name: 检出代码
      uses: actions/checkout@v4
    
    - name: 设置 Python
      uses: actions/setup-python@v5
      with:
        python-version: '3.11'
    
    - name: 安装依赖
      run: |
        pip install -r requirements.txt
        pip install pyinstaller
    
    - name: 打包
      run: |
        pyinstaller --name=DocFormatter --windowed --onefile main.py
    
    - name: 上传产物
      uses: actions/upload-artifact@v4
      with:
        name: DocFormatter-Linux
        path: dist/DocFormatter
```

## ️ 环境变量和密钥

当前工作流不需要额外的密钥。如需添加代码签名：

### Windows 代码签名

```yaml
- name: 签名 exe
  run: |
    # 使用证书签名
    signtool sign /f certificate.pfx /p ${{ secrets.SIGNING_PASSWORD }} dist\DocFormatter.exe
```

### macOS 代码签名和公证

```yaml
- name: 签名和公证
  run: |
    codesign --force --deep --sign "${{ secrets.MACOS_CERTIFICATE }}" dist/DocFormatter.app
    xcrun notarytool submit dist/DocFormatter.dmg --apple-id "${{ secrets.APPLE_ID }}" --password "${{ secrets.APPLE_PASSWORD }}" --team-id "${{ secrets.TEAM_ID }}"
```

## 📊 构建时间估算

| 系统 | 预计时间 |
|------|---------|
| Windows | 5-8 分钟 |
| macOS | 8-12 分钟 |
| Linux | 3-5 分钟 |

## 🐛 故障排除

### 打包失败

1. 查看 Actions 日志
2. 检查错误信息
3. 修改配置后重新推送

### 下载速度慢

GitHub 服务器在国外，可以考虑：
1. 使用代理
2. 使用国内镜像（如 Gitee）

### 打包文件过大

- 使用 UPX 压缩
- 减少不必要的依赖
- 使用 `--onedir` 模式代替 `--onefile`

## 📈 后续优化

1. **自动测试**：打包后自动运行测试
2. **自动部署**：打包后自动上传到服务器
3. **多版本支持**：同时打包多个 Python 版本
4. **夜间构建**：定时打包开发版本

---

**提示**: GitHub Actions 免费额度：
- 公共仓库：无限
- 私有仓库：2000 分钟/月（免费计划）
